# GENERATED VERSION FILE
# TIME: Wed Jan 21 11:27:08 2026
__version__ = '1.2.0+1.4.2'
short_version = '1.2.0'
version_info = (1, 2, 0)
